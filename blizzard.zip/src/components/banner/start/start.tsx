import "./start.css"
import Image from "next/image"
import um from "../../../assets/img/1.png"
import dois from "../../../assets/img/2.png"
import tres from "../../../assets/img/3.png"
import quatro from "../../../assets/img/4.png"
import cinco from "../../../assets/img/5.png"

export default function Start(){
    return (
        <>
        <div className="start">
        <h1>Retorne à escuridão com o game Diablo IV</h1>
            <h3>O retorno de Lilith traz uma era de escuridão e sofrimento</h3>
            <button>Jogue agora</button>
            <div className="logo_games">
                <div className="logo_game active">
                    <Image 
                    src={quatro}
                    alt="logo game"
                    />
                </div>
                <div className="logo_game">
                    <Image 
                    src={dois}
                    alt="logo game"
                    />
                </div>
                <div className="logo_game ">
                    <Image 
                    src={um}
                    alt="logo game"
                    />
                </div>
                <div className="logo_game">
                    <Image 
                    src={tres}
                    alt="logo game"
                    />
                </div>
                
                <div className="logo_game">
                    <Image 
                    src={cinco}
                    alt="logo game"
                    />
                </div>
            </div> 
        </div>       
        </>
    )
}