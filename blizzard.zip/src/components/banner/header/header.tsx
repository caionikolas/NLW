import './header.css'
import Image from "next/image"
import Logo from "../../../assets/img/logo.png"
import Menu from "../../../assets/img/menu.svg"

export default function Header() {
    return (
        <>
            <div className="header">
                <div className="logo">
                    <Image
                        src={Logo}
                        alt='Logo Blizzard'
                    />
                </div>
                <nav>
                <Image
                        src={Menu}
                        alt='Logo Blizzard'
                    />
                </nav>
            </div>
            <hr className='hr-top'/>
        </>
    )
  }