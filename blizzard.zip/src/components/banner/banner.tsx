import Header from "./header/header"
import Image from "next/image"
import Background from "../../assets/img/background.png"
import "./banner.css"
import Start from "./start/start"

export default function Banner(){
    return (
        <>
            <div className="background">
                <Image
                    src={Background}
                    alt="Background"
                />
            </div>
            <Header/>
            <Start/>
            <hr className='hr-bot'/>
        </>
    )      
}