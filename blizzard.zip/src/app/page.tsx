import Banner from '@/components/banner/banner'

export default function Home() {
  return (
    <Banner/>
  )
}
